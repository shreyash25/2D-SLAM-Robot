#!/bin/bash
roslaunch mybot_navigation mybot_teleop.launch
